#! /bin/sh
${srcdir}/out_test.sh nasmpp_test modules/preprocs/nasm/tests "nasm preproc" "-f bin" ""
exit $?
